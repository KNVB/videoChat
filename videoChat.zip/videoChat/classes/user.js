class User
{
	constructor() {
		this.email;
		this.alias;
		this.socketId;
	}
}